const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
//const carnetController = require('../controllers/carnetController');

// Routes
// ELECTEUR
        // URL ''controller.fonction;
router.get('/', userController.view);
router.post('/', userController.find);
router.get('/listecarnet', userController.viewcarnet);
router.get('/listeadmin', userController.viewadmin);

router.get('/addcarnet', userController.formCarnet);
router.get('/adduser', userController.form);
router.get('/addadmin', userController.formAdmin);

router.post('/adduser', userController.create);
router.post('/addcarnet', userController.createCarnet);
router.post('/addadmin', userController.createAdmin);

router.get('/edituser/:id', userController.edit);
router.get('/editcarnet/:id', userController.editCarnet);
router.get('/editadmin/:id', userController.editAdmin);

router.post('/edituser/:id', userController.update);
router.post('/editcarnet/:id', userController.updateCarnet);
router.post('/editadmin/:id', userController.updateAdmin);

router.get('/viewuser/:id', userController.viewall);
router.get('/:id',userController.deleteelecteur); 
router.get('/listecarnet/:id',userController.deleteCarnet); 
router.get('/listeadmin/:id',userController.deleteAdmin); 


// ELECTEUR
//router.get('/listecarnet', userController.viewcarnet);
//router.post('/find', carnetController.find);
//router.get('/addcarnet', carnetController.form);
//router.post('/addcarnet', carnetController.create);
//router.get('/edituser/:id', carnetController.edit);
//router.post('/edituser/:id', carnetController.update);
//router.get('/viewuser/:id', carnetController.viewall);
//router.get('/:id',carnetController.delete); 
module.exports = router;