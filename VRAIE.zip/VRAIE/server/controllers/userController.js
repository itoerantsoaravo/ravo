const mysql = require('mysql');

// Connection Pool
let connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
});

// View Users fct
exports.view = (req, res) => {
  // User mk bd
  connection.query('SELECT * from electeur', (err, rows) => {
    // When done with the connection, release it 
    if (!err) {
      let removedUser = req.query.removed;
      res.render('home', { rows, removedUser });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}
// liste carnet
exports.viewcarnet = (req, res) => {
  // User the connection
  connection.query('SELECT * from carnet', (err, rows) => {
    // When done with the connection, release it
    if (!err) {
      let removedUser = req.query.removed;
      res.render('listeCarnet', { rows, removedUser });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}

exports.viewadmin = (req, res) => {
  // User the connection
  connection.query('SELECT * from administration', (err, rows) => {
    // When done with the connection, release it
    if (!err) {
      let removedUser = req.query.removed;
      res.render('listeadministration', { rows, removedUser });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}

// Find User by Search
exports.find = (req, res) => {
  let searchTerm = req.body.search;
  // User the connection
  connection.query('SELECT * electeur WHERE numero_carnet LIKE ? OR nom_elect  LIKE ? OR prenom LIKE ?', ['%' + searchTerm + '%','%' + searchTerm + '%', '%' + searchTerm + '%'], (err, rows) => {
    if (!err) {
      res.render('home', { rows });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}

exports.form = (req, res) => {
  res.render('add-user');
}

// Add new user
exports.create = (req, res) => {
  const { numero, nom, prenom, sexe, date, lieu,proffession,adresse, cin } = req.body;
  let searchTerm = req.body.search;

  // User the connection
  connection.query('INSERT INTO electeur SET numero_carnet = ?, nom_elect  = ?, prenom = ?, sexe = ?, date_naisssance = ?,lieu_naissance = ?, proffession = ?, adresse = ?, cin =?', [numero , nom  , prenom , sexe , date ,lieu , proffession , adresse , cin ], (err, rows) => {
    if (!err) {
      res.render('add-user', { alert: 'Electeur bien eregistrée.' });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}


// Edit user
exports.edit = (req, res) => {
  // User the connection
  connection.query('SELECT * from electeur WHERE id = ?', [req.params.id], (err, rows) => {
    if (!err) {
      res.render('edit-user', { rows });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}


// Update User
exports.update = (req, res) => {
  const { numero , nom  , prenom , sexe , date ,lieu , proffession , adresse , cin} = req.body;
  // User the connection
  connection.query('UPDATE  electeur SET  numero_carnet = ?, nom_elect  = ?, prenom = ?, sexe = ?, date_naisssance = ?,lieu_naissance = ?, proffession = ?, adresse =? , cin =? WHERE id = ?', [numero , nom , prenom , sexe , date ,lieu , proffession , adresse , cin, req.params.id], (err, rows) => {

    if (!err) {
      // User the connection
      connection.query('SELECT * FROM electeur WHERE id = ?', [req.params.id], (err, rows) => {
        // When done with the connection, release it
        
        if (!err) {
          res.render('edit-user', { rows, alert: `${numero} bien mmodifier.` });
        } else {
          console.log(err);
        }
        console.log('The data from user table: \n', rows);
      });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}

// Delete User
exports.deleteelecteur = (req, res) => {
  connection.query('DELETE FROM electeur WHERE id = ?', [req.params.id], (err, rows) => {

    if(!err) {
      let removedUser = encodeURIComponent('bien supprimer.');
      res.redirect('/');
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  
    });
  
}
exports.delete = (req, res) => {

  // Delete a record

  // User the connection
  // connection.query('DELETE FROM user WHERE id = ?', [req.params.id], (err, rows) => {

  //   if(!err) {
  //     res.redirect('/');
  //   } else {
  //     console.log(err);
  //   }
  //   console.log('The data from user table: \n', rows);

  // });

  // Hide a record
/*
  connection.query('UPDATE electeur SET  WHERE id = ?', ['removed', req.params.id], (err, rows) => {
    if (!err) {
      let removedUser = encodeURIComponent('User successeflly removed.');
      res.redirect('/?removed=' + removedUser);
    } else {
      console.log(err);
    }
    console.log('The data from beer table are: \n', rows);
  }); */

}

// View Users
exports.viewall = (req, res) => {

  // User the connection
  connection.query('SELECT * FROM electeur WHERE id = ?', [req.params.id], (err, rows) => {
    if (!err) {
      res.render('view-user', { rows });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });

}
//carnet
exports.formCarnet = (req, res) => {
  res.render('add-carnet');
}

// Add new carnet
exports.createCarnet = (req, res) => {
  const { numero, nom } = req.body;
  let searchTerm = req.body.search;

  // User the connection
  connection.query('INSERT INTO carnet SET numero_carnet = ?, nombre  = ?', [numero , nom ], (err, rows) => {
    if (!err) {
      res.render('add-carnet', { alert: 'Carnet bien eregistrée.' });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}

// Edit carnet
exports.editCarnet = (req, res) => {
  // User the connection
  connection.query('SELECT * from carnet WHERE id = ?', [req.params.id], (err, rows) => {
    if (!err) {
      res.render('edit-carnet', { rows });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}
// Update Carnet
exports.updateCarnet = (req, res) => {
  const { numero , nom } = req.body;
  // User the connection
  connection.query('UPDATE  carnet SET  numero_carnet = ?, nombre  = ? WHERE id = ?', [numero , nom , req.params.id], (err, rows) => {

    if (!err) {
      // User the connection
      connection.query('SELECT * FROM carnet WHERE id = ?', [req.params.id], (err, rows) => {
        // When done with the connection, release it
        
        if (!err) {
          res.render('edit-carnet', { rows, alert: `${numero} bien mmodifier.` });
        } else {
          console.log(err);
        }
        console.log('The data from user table: \n', rows);
      });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}

//delete carnet

//SUPPRESSIONS
exports.deleteCarnet = (req, res) => {
  connection.query('DELETE FROM carnet WHERE id = ?', [req.params.id], (err, rows) => {

    if(!err) {
      let removedUser = encodeURIComponent('bien supprimer.');
      res.redirect('/listecarnet');
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  
    });
  
}

//Administration
//view
exports.formAdmin = (req, res) => {
  res.render('add-admin');
}
//Ajout
exports.createAdmin = (req, res) => {
  const { region, district, section, centre_vote, bureau_vote } = req.body;
  let searchTerm = req.body.search;

  // User the connection
  connection.query('INSERT INTO Administration SET region  = ?, district  = ?, section  = ?, centre_vote  = ?, bureau_vote = ?', [region, district, section, centre_vote, bureau_vote ], (err, rows) => {
    if (!err) {
      res.render('add-admin', { alert: 'Administration bien eregistrée.' });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}
// Edit administration
exports.editAdmin = (req, res) => {
  // User the connection
  connection.query('SELECT * from administration WHERE id = ?', [req.params.id], (err, rows) => {
    if (!err) {
      res.render('edit-admin', { rows });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}
// Update admministration
exports.updateAdmin = (req, res) => {
  const { region, district, section, centre_vote, bureau_vote } = req.body;
  // User the connection
  connection.query('UPDATE  administration SET region  = ?, district  = ?, section  = ?, centre_vote  = ?, bureau_vote = ? WHERE id = ?', [region, district, section, centre_vote, bureau_vote , req.params.id], (err, rows) => {

    if (!err) {
      // User the connection
      connection.query('SELECT * FROM administration WHERE id = ?', [req.params.id], (err, rows) => {
        // When done with the connection, release it
        
        if (!err) {
          res.render('edit-admin', { rows, alert: `${region} bien mmodifier.` });
        } else {
          console.log(err);
        }
        console.log('The data from user table: \n', rows);
      });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}
//SUPPRESSIONS
exports.deleteAdmin = (req, res) => {
  connection.query('DELETE FROM administration WHERE id = ?', [req.params.id], (err, rows) => {

    if(!err) {
      let removedUser = encodeURIComponent('bien supprimer.');
      res.redirect('/listeadmin');
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  
    });
  
}